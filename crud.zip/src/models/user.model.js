const file = (sequelize, DataTypes) => {
  const File = sequelize.define(
      'user',
      {
          name: {
              type: DataTypes.STRING,
              allowNull: false,
              validate: {
                  notEmpty: true,
              },
          },
          email: {
              type: DataTypes.STRING,
              allowNull: false,
              validate: {
                  notEmpty: true,
              },
          },
          address: {
              type: DataTypes.STRING,
              allowNull: false,
              validate: {
                  notEmpty: true,
              },
          },
          phoneNumber: {
              type: DataTypes.STRING,
              allowNull: false,
              validate: {
                  notEmpty: true,
              },
          },
          userId: {
              type: DataTypes.INTEGER,
              allowNull: false,
          }
      },
      {
          timestamps: true,
      }
  );
  return File;
};

module.exports = file;
