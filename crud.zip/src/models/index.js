const Sequelize = require('sequelize');
const pg = require('pg');
const config = require('../config/config');
const user = require('./user.model');

pg.defaults.ssl = false;

const sequelize = new Sequelize(config.postgres.url, {
  dialect: 'postgres',
  ssl: false,
  // dialectOptions: { 
  //   ssl: {
  //     require: true,
  //     rejectUnauthorized: false,
  //   },
  // },
});

const models = {
  User: user(sequelize, Sequelize),
};

models.User.belongsTo(models.User);


Object.keys(models).forEach((key) => {
  if ('associate' in models[key]) {
    models[key].associate(models);
  }
});

module.exports = { sequelize, models };