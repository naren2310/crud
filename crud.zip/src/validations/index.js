module.exports.authValidation = require('./auth.validation');
module.exports.userValidation = require('./user.validation');
module.exports.fileValidation = require('./file.validation');
module.exports.employeevalidation = require('./employee.validation');