
module.exports.userService = require('./user.service');